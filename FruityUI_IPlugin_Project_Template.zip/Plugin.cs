﻿using System;
using FruityUI;

namespace Plugin
{

    // class name can be called whatever
    class Settings : ISettings
    {

        // Required
        public string _database;
        public string database { get { return _database; } }

        public Settings(string db)
        {
            _database = db;
        }

        // Settings that are saved, and updated must contain a getter/setter

        public string example { get; set; }

    }

    // class name can be called whatever
    class Plugin : IPlugin, IDisposable
    {

        private string _author = "YOUR_NAME";
        private string _name = "PLUGIN_NAME";
        private string _description = "PLUGIN_DESCRIPTION";

        public string author { get { return _author; } }
        public string name { get { return _name; } }
        public string description { get { return _description; } }

        private Settings settings;

        protected static Core core;

        public Plugin(Core c)
        {

            core = c;

            // Use settings only if you need to store data

            settings = new Settings(_name);
            core.getSettings(settings); // update settings
            core.updateSettings(settings); // save settings

        }

        ~Plugin()
        {
            Dispose();
        }

        public void Dispose()
        {
            core.updateSettings(settings); // if you are using settings, save on Dispose to not have a risk of loosing data.
            GC.SuppressFinalize(this);
        }

    }

}